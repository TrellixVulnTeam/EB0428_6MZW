#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2019/10/23 19:08
# @Author  : userzhang
# a = [{1:"1",2:"2"},{3:'4'}]
#
# for i in a:
#     i.update({4:'4'})
# print(a)

