# from django.test import TestCase
#
# # Create your tests here.
d = {"a": ""}

print(d.get("b", "1111"))
print(d)