#!/bin/bash

cd /home/iot/edgeBox/edgebox_final/
source /home/iot/edgeBox/ebenv/edgebox_env/bin/activate
python /home/iot/edgeBox/edgebox_final/manage.py celerybeat